# Illustrates an API call to Datafiniti's Business Database for hotels.
import requests
import urllib.parse
import json

# Set your API parameters here.
API_token = 'AAAXXXXXXXXXXXX'
format = 'JSON'
query = 'categories:hotels'
num_records = 1
download = False

request_headers = {
    'Authorization': 'Bearer ' + API_token,
    'Content-Type': 'application/json',
}
request_data = {
    'query': query,
    'format': format,
    'num_records': num_records,
    'download': download
}

# Make the API call.
r = requests.post('https://api.datafiniti.co/v4/businesses/search',json=request_data,headers=request_headers);

# Do something with the response.
if r.status_code == 200:
    print(r.content)
else:
    print('Request failed')